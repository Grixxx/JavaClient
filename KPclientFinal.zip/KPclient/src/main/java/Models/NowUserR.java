package Models;

public class NowUserR extends User{

    private static NowUserR instance;

    private NowUserR(){

    }

    public NowUserR(int idUser, String firstName, String lastName, String login, String password, String role) {
        super(idUser, firstName, lastName, login, password, role );
    }

    public NowUserR(String firstName, String lastName, String login, String password) {
        super(firstName, lastName, login, password);
    }

    public static NowUserR getInstance(){
        if(instance == null){
            instance = new NowUserR();
            return instance;
        }
        return instance;
    }
}

//