package Models;

import java.math.BigDecimal;

public class Specialtie {
    private int idSpecialtie;
    private String specialtieName;


    public Specialtie(){

    }


    public Specialtie (int idSpecialtie, String specialtieName ){
        this.idSpecialtie = idSpecialtie;
        this.specialtieName = specialtieName;
    }

    public int getIdSpecialtie() {
        return idSpecialtie;
    }

    public void setIdSpecialtie(int idSpecialtie) {
        this.idSpecialtie = idSpecialtie;
    }

    public String getSpecialtieName() {
        return specialtieName;
    }

    public void setSpecialtieName(String specialtieName) {
        this.specialtieName = specialtieName;
    }
}
